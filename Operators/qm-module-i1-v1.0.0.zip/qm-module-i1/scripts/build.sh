#!/usr/bin/env bash
# ============================================================
# build.sh — Generate all Module I.1 lecture decks
# Usage: bash scripts/build.sh
# ============================================================

set -e

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$REPO_ROOT/src/generate_lectures.js"
OUT="$REPO_ROOT/generated"

echo "=============================================="
echo "  QM Module I.1 — Lecture Deck Generator"
echo "=============================================="
echo ""

# Check Node.js
if ! command -v node &>/dev/null; then
  echo "ERROR: Node.js is not installed. Please install Node.js v18+."
  exit 1
fi

NODE_VERSION=$(node -e "process.stdout.write(process.version)")
echo "Node.js: $NODE_VERSION"

# Install deps if needed
if [ ! -d "$REPO_ROOT/node_modules" ]; then
  echo "Installing dependencies..."
  cd "$REPO_ROOT" && npm install --silent
fi

# Ensure output directory exists
mkdir -p "$OUT"

# Run generator
echo ""
echo "Generating lecture decks..."
echo ""
node "$SRC"

echo ""
echo "Output files:"
ls -lh "$OUT"/*.pptx 2>/dev/null || echo "  (none found)"

echo ""
echo "Done. Files written to: $OUT/"
